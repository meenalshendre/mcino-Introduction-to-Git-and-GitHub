# Simple Interest Calculator

A simple Bash script that calculates simple interest from the principal amount, annual rate of interest, and time period supplied by the user.

## Formula

Simple Interest = (Principal × Rate × Time) / 100

## Requirements

- Bash shell
- A terminal

## Run the calculator

```bash
chmod +x simple-interest.sh
./simple-interest.sh
```

Enter the principal amount, annual rate of interest, and time period when prompted. The script displays the simple interest and total amount (principal plus interest).

## Project file

- `simple-interest.sh` — interactive Bash simple-interest calculator.

## License

This project is provided under the Apache License 2.0. See `LICENSE`.
