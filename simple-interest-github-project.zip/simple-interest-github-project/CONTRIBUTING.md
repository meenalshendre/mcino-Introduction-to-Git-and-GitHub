# Contributing

All contributions, bug reports, bug fixes, documentation improvements, enhancements, and ideas are welcome.

## How to contribute

1. Fork the repository.
2. Create a branch for your change.
3. Make your changes and test them.
4. Commit your changes with a clear message.
5. Open a pull request describing what you changed and why.

Please keep contributions focused and provide enough detail for others to review them.
