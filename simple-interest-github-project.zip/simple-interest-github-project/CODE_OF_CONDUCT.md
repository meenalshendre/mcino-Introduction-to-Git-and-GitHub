# Contributor Covenant Code of Conduct

## Our Pledge

We pledge to make participation in this project a welcoming and respectful experience for everyone.

## Our Standards

Examples of behavior that contributes to a positive environment include being considerate, respectful, constructive, and accepting of differing viewpoints. Harassment, insults, and discriminatory behavior are not acceptable.

## Enforcement Responsibilities

Project maintainers are responsible for clarifying and enforcing these standards and may take appropriate corrective action in response to unacceptable behavior.

## Scope

This Code of Conduct applies within project spaces and when an individual is officially representing the project.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the project maintainers. Reports will be reviewed and handled as fairly and promptly as possible.

## Enforcement Guidelines

Maintainers may take action proportionate to the behavior, including a warning, temporary restriction, or removal from project spaces.

## Attribution

This Code of Conduct is adapted from the Contributor Covenant, version 2.1.
